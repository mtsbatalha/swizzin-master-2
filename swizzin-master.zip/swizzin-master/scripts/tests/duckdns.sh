#!/usr/bin/env bash

echo_log_only "No tests to run for duckdns"
